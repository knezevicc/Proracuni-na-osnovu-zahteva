﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Threading;
using Common;

namespace DataBase
{
    public class XmlDatabase
    {
        private readonly string databasePath;
        private Timer updateTimer;

        public XmlDatabase(string databasePath)
        {
            this.databasePath = databasePath;
        }

        public void StartAutoUpdate(TimeSpan interval)
        {
            updateTimer = new Timer(UpdateData, null, TimeSpan.Zero, interval);
        }

        public void StopAutoUpdate()
        {
            updateTimer?.Dispose();
        }

        public void CreateTable<T>()
        {
            string tableName = typeof(T).Name;
            string filePath = GetFilePath(tableName);

            if (!File.Exists(filePath))
            {
                // Kreiranje prazne XML datoteke za tabelu
                File.WriteAllText(filePath, string.Empty);
            }
        }

        public List<T> GetAllRecords<T>()
        {
            string tableName = typeof(T).Name;
            string filePath = GetFilePath(tableName);

            if (!File.Exists(filePath))
            {
                return new List<T>(); // Ako XML datoteka ne postoji, vraćamo praznu listu
            }

            XmlSerializer serializer = new XmlSerializer(typeof(List<T>));
            using (StreamReader reader = new StreamReader(filePath))
            {
                return (List<T>)serializer.Deserialize(reader);
            }
        }

        public void InsertRecord<T>(T record)
        {
            string tableName = typeof(T).Name;
            string filePath = GetFilePath(tableName);

            List<T> records = GetAllRecords<T>();
            records.Add(record);

            XmlSerializer serializer = new XmlSerializer(typeof(List<T>));
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                serializer.Serialize(writer, records);
            }
        }

        private string GetFilePath(string tableName)
        {
            return Path.Combine(databasePath, $"{tableName}.xml");
        }

        private void UpdateData(object state)
        {
            // Implementirajte kod za ažuriranje podataka svakih sat vremena
            // Na primer, možete dobiti podatke iz drugog izvora, izvršiti izračunavanja itd.
            // Zatim ažurirajte podatke u XML datoteci.
            // Dobijanje novih podataka iz drugog izvora
            List<Load> newLoads = GetDataFromExternalSource();

            // Ažuriranje podataka u XML datoteci
            XmlDatabase xmlDatabase = new XmlDatabase("putanja/do/baze/podataka");
            foreach (Load load in newLoads)
            {
                //xmlDatabase.Insert(load);
            }
        }
        private List<Load> GetDataFromExternalSource()
        {
            // Simulacija dobavljanja podataka iz spoljnog izvora
            // Možete prilagoditi ovaj deo koda prema stvarnom izvoru podataka

            // Pretvaranje izvornih podataka u listu objekata Load
            List<Load> loads = new List<Load>();

            // Primer: Generisanje slučajnih podataka
            Random random = new Random();
            for (int i = 0; i < 10; i++)
            {
                Load load = new Load();
                load.Id = i + 1;
                //load.Value = random.Next(100);
                loads.Add(load);
            }

            return loads;
        }

        //INICIJALIZACIJA
        /*public void InitializeDatabase()
        {
            if (!File.Exists(databasePath))
            {
                XmlDocument xmlDoc = new XmlDocument();
                XmlDeclaration xmlDeclaration = xmlDoc.CreateXmlDeclaration("1.0", "UTF-8", null);
                xmlDoc.AppendChild(xmlDeclaration);

                XmlElement rootElement = xmlDoc.CreateElement("Database");
                xmlDoc.AppendChild(rootElement);

                xmlDoc.Save(databasePath);
            }
        }*/

        //UNOS
        /*public void InsertData(string tableName, string[] columnNames, string[] values)
        {
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(databasePath);

            XmlNode rootElement = xmlDoc.SelectSingleNode("Database");

            XmlNode tableNode = xmlDoc.CreateElement(tableName);
            rootElement.AppendChild(tableNode);

            for (int i = 0; i < columnNames.Length; i++)
            {
                XmlNode columnNode = xmlDoc.CreateElement(columnNames[i]);
                columnNode.InnerText = values[i];
                tableNode.AppendChild(columnNode);
            }

            xmlDoc.Save(databasePath);
        }*/

        //CITANJE IZ TABELE
        /*public XmlNodeList ReadData(string tableName)
        {
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(databasePath);

            return xmlDoc.SelectNodes($"//{tableName}");
        }*/

        //********************************

        //Ovo će kreirati XML datoteku pod nazivom "User.xml" u odgovarajućem direktorijumu za bazu podataka. Nakon inicijalizacije, možete koristiti metode za dodavanje i izvlačenje podataka iz tabele User
        /*
         XmlDatabase xmlDatabase = new XmlDatabase("putanja/do/baze/podataka");
         xmlDatabase.CreateTable<User>();
        */
    }
}
