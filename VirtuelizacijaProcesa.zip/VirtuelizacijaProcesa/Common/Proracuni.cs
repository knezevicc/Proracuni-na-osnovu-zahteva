﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    public class Proracuni
    {
        //vrsi proracune na osnovu liste projekata Load

        public static double CalculateMinPower(List<Load> loads)
        {
            if (loads.Count == 0)
            {
                throw new ArgumentException("List of loads is empty.");
            }

            double minPower = loads[0].MeasuredValue;
            foreach (Load load in loads)
            {
                if (load.MeasuredValue < minPower)
                {
                    minPower = load.MeasuredValue;
                }
            }

            return minPower;
        }

        public static double CalculateMaxPower(List<Load> loads)
        {
            if (loads.Count == 0)
            {
                throw new ArgumentException("List of loads is empty.");
            }

            double maxPower = loads[0].MeasuredValue;
            foreach (Load load in loads)
            {
                if (load.MeasuredValue > maxPower)
                {
                    maxPower = load.MeasuredValue;
                }
            }

            return maxPower;
        }

        public static double CalculateStandardDeviation(List<Load> loads)
        {
            double sum = 0;
            double average = CalculateAveragePower(loads);

            foreach (Load load in loads)
            {
                double difference = load.MeasuredValue - average;
                sum += difference * difference;
            }

            double variance = sum / loads.Count;
            double standardDeviation = Math.Sqrt(variance);
            return standardDeviation;
        }


        //pomocna metode,racuna prosecnu potrosnju
        private static double CalculateAveragePower(List<Load> loads)
        {
            double sum = 0;
            foreach (Load load in loads)
            {
                sum += load.MeasuredValue;
            }
            return sum / loads.Count;
        }


        //spojene poslednje 2 metode:
        /*
         public static double CalculateStandardDeviation(List<Load> loads)
{
    if (loads.Count == 0)
    {
        throw new ArgumentException("List of loads is empty.");
    }

    double sum = 0;
    foreach (Load load in loads)
    {
        sum += load.Value;
    }
    double average = sum / loads.Count;

    double sumOfSquaredDifferences = 0;
    foreach (Load load in loads)
    {
        double difference = load.Value - average;
        sumOfSquaredDifferences += difference * difference;
    }

    double variance = sumOfSquaredDifferences / loads.Count;
    double standardDeviation = Math.Sqrt(variance);

    return standardDeviation;
}
         
         
         */
    }
}
