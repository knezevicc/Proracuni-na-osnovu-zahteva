﻿using Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service

    //DELEGATI SVE 
{
    public class ProracuniServer
    {
        public delegate double CalculationDelegate(List<Load> loads);

        public class CalculationService
        {
            // Kreiranje instanci delegata i dodeljivanje metoda
            CalculationDelegate calculateMinPower = Proracuni.CalculateMinPower;
            CalculationDelegate calculateMaxPower = Proracuni.CalculateMaxPower;
            CalculationDelegate calculateStandardDeviation = Proracuni.CalculateStandardDeviation;

            // Metoda za izvršavanje proračuna
            public double PerformCalculation(string calculationType, List<Load> loads)
            {
                double result = 0;

                switch (calculationType)
                {
                    case "MinPower":
                        result = calculateMinPower(loads);
                        break;
                    case "MaxPower":
                        result = calculateMaxPower(loads);
                        break;
                    case "StandardDeviation":
                        result = calculateStandardDeviation(loads);
                        break;
                    default:
                        // Handle unsupported calculation type
                        break;
                }

                return result;
            }
        }
    }
}
