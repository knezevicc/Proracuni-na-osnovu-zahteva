﻿using Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace Service
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceHost host = new ServiceHost(typeof(EstimateService));
            host.Open();
            Console.WriteLine("Service is open, press any key to close it.");


            //DELEGATI
            // Kreiranje instanci delegata i dodeljivanje metoda
            CalculationDelegate calculateMinPower = Proracuni.CalculateMinPower;
            CalculationDelegate calculateMaxPower = Proracuni.CalculateMaxPower;
            CalculationDelegate calculateStandardDeviation = Proracuni.CalculateStandardDeviation;

            //ovo je metoda za dobijanje podataka iz database
 //           List<Load> loads = GetDataFromDatabase(); // Pretpostavka: Metoda za dobijanje podataka iz baze

            //koriscenje delegata za izvrsabvanje dogadjdja
      //      double minPower = minPowerDelegate(loads);
      //      double maxPower = maxPowerDelegate(loads);
      //      double stdDev = stdDevDelegate(loads);

            //DELEGATI


            Console.ReadKey();
            host.Close();
            Console.WriteLine("Service is closed");
        }
    }

    // Definisanje delegata-common-proracuni tu je ostatak koda
    public delegate double CalculationDelegate(List<Load> loads);

    

}

